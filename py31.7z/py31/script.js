// ==================== 1. 取得 HTML 元素 ====================
const addContactForm = document.getElementById('add-contact-form');
const contactListBody = document.getElementById('contact-list-body');
const searchForm = document.getElementById('search-form');

// 編輯相關元素
const editSection = document.getElementById('edit-section');
const editContactForm = document.getElementById('edit-contact-form');
const cancelEditBtn = document.getElementById('cancel-edit');


// ==================== 2. 資料儲存與初始化 ====================
// 從 localStorage 載入資料，如果沒有則為空陣列
let contacts = JSON.parse(localStorage.getItem('phonebookContacts')) || [];

/**
 * 儲存資料到 localStorage
 */
function saveContacts() {
    localStorage.setItem('phonebookContacts', JSON.stringify(contacts));
}


// ==================== 3. 渲染 (Rendering) 聯絡人列表 ====================
/**
 * 根據傳入的聯絡人陣列渲染表格
 * @param {Array} list 要顯示的聯絡人陣列
 */
function renderContacts(list) {
    contactListBody.innerHTML = ''; 

    if (list.length === 0) {
        contactListBody.innerHTML = '<tr><td colspan="4" style="text-align: center;">查無聯絡人資料。</td></tr>';
        return;
    }

    list.forEach(contact => {
        const row = contactListBody.insertRow();

        row.insertCell().textContent = contact.name;
        row.insertCell().textContent = contact.phone;
        row.insertCell().textContent = contact.email;

        const actionCell = row.insertCell();
        
        // ** 編輯按鈕：綁定 handleEdit **
        const editBtn = document.createElement('button');
        editBtn.textContent = '編輯';
        editBtn.className = 'btn edit-btn';
        // 將聯絡人完整資料存儲為 data 屬性
        editBtn.dataset.contact = JSON.stringify(contact); 
        editBtn.addEventListener('click', handleEdit); 
        
        // 刪除按鈕
        const deleteBtn = document.createElement('button');
        deleteBtn.textContent = '刪除';
        deleteBtn.className = 'btn delete-btn';
        deleteBtn.dataset.phone = contact.phone; 
        deleteBtn.addEventListener('click', handleDelete);
        
        actionCell.appendChild(editBtn);
        actionCell.appendChild(deleteBtn);
    });
}


// ==================== 4. 事件處理函數 (Add, Delete, Search) ====================

function handleAdd(event) {
    event.preventDefault();

    const name = document.getElementById('name').value.trim();
    const phone = document.getElementById('phone').value.trim();
    const email = document.getElementById('email').value.trim();
    
    // 檢查電話號碼格式
    if (!/^\d{10}$/.test(phone)) {
        alert("新增失敗：電話號碼格式錯誤，請輸入10位數字。");
        return;
    }

    // 檢查重複
    const isDuplicate = contacts.some(contact => contact.phone === phone);
    if (isDuplicate) {
        alert(`新增失敗：電話號碼 ${phone} 已存在於電話簿中！`);
        return;
    }

    const newContact = { name, phone, email };

    contacts.push(newContact);
    // 依姓名排序
    contacts.sort((a, b) => a.name.localeCompare(b.name, 'zh-Hant'));

    saveContacts();
    renderContacts(contacts);

    addContactForm.reset();
    alert(`已成功新增聯絡人：${name}`);
}

function handleDelete(event) {
    const phoneToDelete = event.target.dataset.phone;

    if (confirm(`確定要刪除電話號碼為 ${phoneToDelete} 的聯絡人嗎？`)) {
        contacts = contacts.filter(contact => contact.phone !== phoneToDelete);
        
        saveContacts();
        // 刪除後，重新執行一次搜尋，確保在搜尋結果頁面也能正確更新
        handleSearch(new Event('submit')); 
    }
}

function handleSearch(event) {
    if (event && event.preventDefault) {
        event.preventDefault(); 
    }

    const searchTerm = document.getElementById('search-term').value.trim().toLowerCase();
    
    if (searchTerm === '') {
        renderContacts(contacts);
        return;
    }

    const searchResults = contacts.filter(contact => {
        const nameMatch = contact.name.toLowerCase().includes(searchTerm);
        const phoneMatch = contact.phone.includes(searchTerm);
        return nameMatch || phoneMatch;
    });

    renderContacts(searchResults);
}


// ==================== 5. 編輯功能處理函數 (新增) ====================

/**
 * 處理點擊「編輯」按鈕事件：顯示表單並填充資料
 */
function handleEdit(event) {
    const contactData = JSON.parse(event.target.dataset.contact);

    // 顯示編輯區塊
    editSection.style.display = 'block';
    
    // 填充資料
    document.getElementById('edit-name').value = contactData.name;
    document.getElementById('edit-phone').value = contactData.phone;
    document.getElementById('edit-email').value = contactData.email;
    
    // 設定隱藏的舊電話號碼 (作為識別 ID)
    document.getElementById('edit-original-phone').value = contactData.phone;
    
    // 讓頁面滾動到編輯表單的位置
    editSection.scrollIntoView({ behavior: 'smooth' });
}

/**
 * 處理編輯表單的提交 (確認修改)
 */
function handleEditSubmit(event) {
    event.preventDefault();

    const originalPhone = document.getElementById('edit-original-phone').value;
    const newName = document.getElementById('edit-name').value.trim();
    const newPhone = document.getElementById('edit-phone').value.trim();
    const newEmail = document.getElementById('edit-email').value.trim();
    
    // 檢查新電話號碼格式
    if (!/^\d{10}$/.test(newPhone)) {
        alert("更新失敗：電話號碼格式錯誤，請輸入10位數字。");
        return;
    }

    // 檢查新電話號碼是否與其他現有聯絡人重複
    const isDuplicate = contacts.some(contact => 
        contact.phone === newPhone && contact.phone !== originalPhone
    );
    if (isDuplicate) {
        alert(`更新失敗：新的電話號碼 ${newPhone} 已被其他聯絡人使用！`);
        return;
    }

    // 找到要修改的聯絡人索引
    const contactIndex = contacts.findIndex(c => c.phone === originalPhone);

    if (contactIndex !== -1) {
        // 更新資料
        contacts[contactIndex].name = newName;
        contacts[contactIndex].phone = newPhone; 
        contacts[contactIndex].email = newEmail;
        
        contacts.sort((a, b) => a.name.localeCompare(b.name, 'zh-Hant'));

        saveContacts();
        
        // 隱藏編輯表單並重設
        editSection.style.display = 'none';
        editContactForm.reset();
        
        // 重新渲染列表
        renderContacts(contacts);
        alert(`聯絡人 ${newName} 資料已成功更新！`);
    } else {
        alert("錯誤：找不到要編輯的聯絡人。");
    }
}


// ==================== 6. 綁定事件監聽器 ====================
addContactForm.addEventListener('submit', handleAdd);
searchForm.addEventListener('submit', handleSearch);
editContactForm.addEventListener('submit', handleEditSubmit);

// 綁定取消按鈕事件
cancelEditBtn.addEventListener('click', () => {
    editSection.style.display = 'none';
    editContactForm.reset();
});


// ==================== 7. 程式啟動點 ====================
// 頁面載入完成後，執行一次渲染
renderContacts(contacts);