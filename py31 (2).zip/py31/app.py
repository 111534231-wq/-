import sqlite3
from flask import Flask, render_template, request, redirect, url_for, flash
import smtplib
from email.mime.text import MIMEText
from email.header import Header
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'your_private_key'

DATABASE = 'database.db'

# --- 郵件伺服器配置 ---
MAIL_HOST = "*****"
MAIL_PORT = ****
MAIL_USER = "****" 
MAIL_PASS = "*****" 

def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

# 計算距離下次生日還有幾天
def days_until_birthday(birthday_str):
    if not birthday_str: return None
    try:
        today = datetime.today().date()
        bday = datetime.strptime(birthday_str, '%Y-%m-%d').date()
        next_bday = bday.replace(year=today.year)
        if next_bday < today:
            next_bday = next_bday.replace(year=today.year + 1)
        return (next_bday - today).days
    except:
        return None

def init_db():
    conn = get_db_connection()
    conn.execute('CREATE TABLE IF NOT EXISTS contacts (name TEXT, phone TEXT PRIMARY KEY, email TEXT);')
    conn.execute('CREATE TABLE IF NOT EXISTS user_profile (id INTEGER PRIMARY KEY, name TEXT, email TEXT);')
    
    # 自動升級資料庫欄位
    try:
        conn.execute('ALTER TABLE contacts ADD COLUMN category TEXT DEFAULT "其他";')
    except: pass
    try:
        conn.execute('ALTER TABLE contacts ADD COLUMN birthday TEXT;')
    except: pass

    if not conn.execute("SELECT * FROM user_profile WHERE id = 1").fetchone():
        conn.execute("INSERT INTO user_profile (id, name, email) VALUES (1, '管理者', 'admin@example.com')")
    conn.commit()
    conn.close()

init_db()

@app.route('/', methods=('GET', 'POST'))
def index():
    conn = get_db_connection()
    user_info = conn.execute("SELECT * FROM user_profile WHERE id = 1").fetchone()
    search_term = ''
    edit_contact_data = None 

    if 'edit_data' in request.args:
        phone_to_edit = request.args.get('edit_data')
        edit_contact_data = conn.execute("SELECT * FROM contacts WHERE phone = ?", (phone_to_edit,)).fetchone()

    query = "SELECT * FROM contacts"
    params = []
    if request.method == 'POST' and 'search-term' in request.form:
        search_term = request.form.get('search-term', '').strip()
        query += " WHERE name LIKE ? OR phone LIKE ?"
        params = ['%' + search_term + '%', '%' + search_term + '%']
    
    query += " ORDER BY name"
    rows = conn.execute(query, params).fetchall()
    
    # 處理生日倒數資料
    contacts = []
    for row in rows:
        contact_dict = dict(row)
        contact_dict['days_to_bday'] = days_until_birthday(row['birthday'])
        contacts.append(contact_dict)

    conn.close()
    return render_template('index.html', contacts=contacts, search_term=search_term, edit_contact=edit_contact_data, user_info=user_info)

@app.route('/add', methods=['POST'])
def add_contact():
    name = request.form['name']
    phone = request.form['phone']
    email = request.form['email']
    category = request.form.get('category', '其他')
    birthday = request.form.get('birthday')

    if len(phone) != 10 or not phone.isdigit():
        flash('錯誤：電話號碼必須為 10 位數字')
        return redirect(url_for('index'))

    conn = get_db_connection()
    try:
        conn.execute("INSERT INTO contacts (name, phone, email, category, birthday) VALUES (?, ?, ?, ?, ?)", 
                     (name, phone, email, category, birthday))
        conn.commit()
    except:
        flash('新增失敗：電話號碼可能已重複')
    conn.close()
    return redirect(url_for('index'))

@app.route('/edit_submit', methods=['POST'])
def edit_contact_submit():
    name = request.form['edit_name']
    new_phone = request.form['edit_phone']
    email = request.form['edit_email']
    category = request.form.get('edit_category', '其他')
    birthday = request.form.get('edit_birthday')
    original_phone = request.form['edit_original_phone']

    conn = get_db_connection()
    conn.execute("UPDATE contacts SET name=?, phone=?, email=?, category=?, birthday=? WHERE phone=?", 
                 (name, new_phone, email, category, birthday, original_phone))
    conn.commit()
    conn.close()
    return redirect(url_for('index'))

@app.route('/delete/<phone_number>')
def delete_contact(phone_number):
    conn = get_db_connection()
    conn.execute("DELETE FROM contacts WHERE phone = ?", (phone_number,))
    conn.commit()
    conn.close()
    return redirect(url_for('index'))

@app.route('/edit_get/<phone_number>')
def edit_contact_get(phone_number):
    return redirect(url_for('index', edit_data=phone_number))

@app.route('/send_email/<email_address>')
def send_email_page(email_address):
    conn = get_db_connection()
    user_info = conn.execute("SELECT * FROM user_profile WHERE id = 1").fetchone()
    conn.close()
    return render_template('send_email.html', recipient=email_address, user_info=user_info)

@app.route('/submit_email', methods=['POST'])
def submit_email():
    recipient, subject, body = request.form['recipient'], request.form['subject'], request.form['body']
    msg = MIMEText(body, 'plain', 'utf-8')
    msg['From'], msg['To'], msg['Subject'] = MAIL_USER, recipient, Header(subject, 'utf-8')
    try:
        server = smtplib.SMTP(MAIL_HOST, MAIL_PORT)
        server.starttls()
        server.login(MAIL_USER, MAIL_PASS)
        server.sendmail(MAIL_USER, [recipient], msg.as_string())
        server.quit()
        flash('郵件已成功寄出')
    except Exception as e:
        flash(f'寄送失敗: {e}')
    return redirect(url_for('index'))

@app.route('/update_profile', methods=['POST'])
def update_profile():
    u_name, u_email = request.form['u_name'], request.form['u_email']
    conn = get_db_connection()
    conn.execute("UPDATE user_profile SET name = ?, email = ? WHERE id = 1", (u_name, u_email))
    conn.commit()
    conn.close()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)